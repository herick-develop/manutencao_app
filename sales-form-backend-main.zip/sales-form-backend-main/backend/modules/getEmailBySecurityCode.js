const securityCodes = [
    {code:'JFVWLY', email:'umuprev.vendas.umuarama@gmail.com'}, //umuarama
    {code:'MKBRFD', email:'umuprev.vendas.cascavel@gmail.com'}, //cascavel
    {code:'TAYB2X', email:'umuprev.vendas.toledo@gmail.com'}, //toledo
    {code:'YUTWWU', email:'umuprev.vendas.guarapuava@gmail.com'}, //guarapuava
    {code:'5X9TV7', email:'umuprev.vendas.cacoal@gmail.com'}, //cacoal
]

const getEmailBySecurityCode = (securityCode) => {
    
    const data = securityCodes.filter( (element) => element.code === securityCode);
    return data[0].email;
};

module.exports = {getEmailBySecurityCode};