//var num = 1;
var strings = [];
const geraStringAleatoria = () =>{
    
    let stringAleatoria;
    do {
        stringAleatoria = Date.now() + Math.random().toString().replace('.', '');
        // if(num == 1 || num == 2) {
        //     stringAleatoria = 'a';
        // } else if(num == 3 || num == 4 || num == 5) {
        //     stringAleatoria = 'b';
        // } else if(num == 6 || num ==7 || num == 8) {
        //     stringAleatoria = 'c';
        // } else {console.log('deu ruim')}
        // num++;
        if(strings.includes(stringAleatoria)) continue
        strings.push(stringAleatoria);
        break;
    } while (true)

    return stringAleatoria;
}

const clearStrings = () => {
    console.log({ strings })
    strings = [];
}

module.exports = { geraStringAleatoria , clearStrings };