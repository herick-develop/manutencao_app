//we use html-pdf for pdf
const pdf = require('html-pdf')
const path = require('path')
const nodemailer = require('nodemailer')
const fs = require('fs')
const pdfTemplate = require("./documents/titular.js")
const pdfTemplateA = require("./documents/dependentesPDF.js")
const env = require('dotenv')
const PDFMerger = require('pdf-merger-js');
const {getEmailBySecurityCode} = require('./modules/getEmailBySecurityCode.js');

const { geraStringAleatoria, clearStrings } = require('./modules/random');

env.config()

var options = {
    
}

function clearStorage({ nameContrato, nameDependentes, nameMerge, nameCpf, nameCompEndereco, nameRgFrente, nameRgVerso }) {

    console.log('callClear');

    if(nameContrato) {
        fs.existsSync( path.join(__dirname, 'pdfs', 'pdfTitular',nameContrato + '.pdf') ) ? fs.unlinkSync( path.join(__dirname, 'pdfs', 'pdfTitular',nameContrato + '.pdf') ) : ''
        console.log('clear PDF Titular');
    }
    
    if(nameDependentes) {
        fs.existsSync( path.join(__dirname, 'pdfs', 'pdfDependente', nameDependentes+ '.pdf') ) ? fs.unlinkSync( path.join(__dirname, 'pdfs', 'pdfDependente',nameDependentes+ '.pdf') ) : ''
        console.log('clear PDF Dependentes');
    }
    
    if(nameMerge) {
        fs.existsSync( path.join(__dirname, 'pdfs', 'pdfMerged',nameMerge+ '.pdf') ) ? fs.unlinkSync( path.join(__dirname, 'pdfs', 'pdfMerged',nameMerge+ '.pdf') ) : ''
        console.log('clear PDF Merged');
    }
    
    if(nameCpf) {
        fs.existsSync( path.join(__dirname, 'uploads', 'cpfs' ,nameCpf) ) ? fs.unlinkSync( path.join(__dirname, 'uploads', 'cpfs',nameCpf) ) : ''
        console.log('clear CPF');
    }
    
    if(nameCompEndereco) {
        fs.existsSync( path.join(__dirname, 'uploads', 'compEnderecos' ,nameCompEndereco) ) ? fs.unlinkSync( path.join(__dirname, 'uploads', 'compEnderecos', nameCompEndereco) ) : ''
        console.log('clear Comp Endereco');
    }
    
    if(nameRgFrente) {
        fs.existsSync( path.join(__dirname, 'uploads', 'rgFrentes' ,nameRgFrente) ) ? fs.unlinkSync( path.join(__dirname, 'uploads', 'rgFrentes',nameRgFrente) ) : ''
        console.log('clear RG Frente');
    }
    
    if(nameRgVerso) {
        fs.existsSync( path.join(__dirname, 'uploads', 'rgVersos' ,nameRgVerso) ) ? fs.unlinkSync( path.join(__dirname, 'uploads', 'rgVersos',nameRgVerso) ) : ''
        console.log('clear RG Verso');
    }

}

exports.createPdf = (req,res)=>{

    let nameContrato;
    let nameDependentes;
    let nameMerge;
    let nameCpf,nameCompEndereco,nameRgFrente,nameRgVerso;
    //console.log(req.files[0])

    req.files.map( (file) => {

        console.log({ file })

        if(file.originalname == 'cpf') {
            nameCpf = file.filename;
        } else if( file.originalname == 'compEndereco' ) {
            nameCompEndereco = file.filename;
        } else if( file.originalname == 'rgFrente' ) {
            nameRgFrente = file.filename;
        }
        else if( file.originalname == 'rgVerso' ) {
            nameRgVerso = file.filename;
        } else {
            console.log('name invalido');
        }
    } )

    const parsedBody = JSON.parse(req.body.document);

    nameContrato = geraStringAleatoria();

    pdf.create(pdfTemplate(parsedBody), options).toFile(path.join(__dirname, 'pdfs', 'pdfTitular', nameContrato+'.pdf'), (err)=>{
        if(err){
            console.log(err);
        } else {}
        // INICIO - NÃO TÁ USANDO
        // pathToAttachment = path.join(__dirname, 'pdfs', 'pdfTitular',nameContrato+'.pdf')
        // attachment = fs.readFileSync(pathToAttachment).toString("base64")
    
        // pathToCpfAttachment = nameCpf ? path.join(__dirname, 'uploads', 'cpfs' , nameCpf) : '';

        // cpfAttachment = nameCpf ? fs.readFileSync(pathToCpfAttachment).toString("base64") : '';

        // //console.log(nameCpf)

        // pathToCompEnderecoAttachment = path.join(__dirname, 'uploads', 'compEnderecos', nameCompEndereco)
        // compEnderecoAttachment = fs.readFileSync(pathToCompEnderecoAttachment).toString("base64")

        // pathToRgFrenteAttachment = path.join(__dirname, 'uploads', 'rgFrentes' ,nameRgFrente)
        // rgFrenteAttachment = fs.readFileSync(pathToRgFrenteAttachment).toString("base64")

        // pathToRgVersoAttachment = path.join(__dirname, 'uploads', 'rgVersos' ,nameRgVerso)
        // rgVersoAttachment = fs.readFileSync(pathToRgVersoAttachment).toString("base64")
        // FIM - NÃO TÁ USANDO

        nameDependentes = geraStringAleatoria(1);

        pdf.create(pdfTemplateA(parsedBody), options).toFile(path.join(__dirname,'pdfs', 'pdfDependente',nameDependentes+'.pdf'),(err)=>{
            if(err){
                console.log(err);
            } else {}

            // INICIO - Não ta usando
            // pathToAttachment = path.join(__dirname, 'pdfs', 'pdfDependente' ,nameDependentes+'.pdf')
            // attachment = fs.readFileSync(pathToAttachment).toString("base64")
        
            // pathToCpfAttachment = path.join(__dirname, 'uploads', 'cpfs' ,nameCpf)
            // cpfAttachment = fs.readFileSync(pathToCpfAttachment).toString("base64")

    
            // pathToCompEnderecoAttachment = path.join(__dirname, 'uploads', 'compEnderecos',nameCompEndereco)
            // compEnderecoAttachment = fs.readFileSync(pathToCompEnderecoAttachment).toString("base64")
    
            // pathToRgFrenteAttachment = path.join(__dirname, 'uploads', 'rgFrentes', nameRgFrente)
            // rgFrenteAttachment = fs.readFileSync(pathToRgFrenteAttachment).toString("base64")
    
            // pathToRgVersoAttachment = path.join(__dirname, 'uploads', 'rgVersos', nameRgVerso)
            // rgVersoAttachment = fs.readFileSync(pathToRgVersoAttachment).toString("base64")
            // FIM - Não ta usando

            //cpfExtension = req.file.filename.split('.').slice(-1)[0];

            nameMerge = geraStringAleatoria(1);

            var merger = new PDFMerger();


            (async () => {
                
                await merger.add(path.join(__dirname, 'pdfs', 'pdfTitular',nameContrato+'.pdf'));

                parsedBody.temDependentes?
                    await merger.add(path.join(__dirname, 'pdfs', 'pdfDependente',nameDependentes+'.pdf'))
                : '';
                
                await merger.save(path.join(__dirname, 'pdfs', 'pdfMerged',nameMerge+'.pdf'));
                
    
                //res.sendFile(path.join(__dirname, 'pdfs' ,'merged.pdf'));
                console.log('created');

                (async () => {
                    console.log('async');
                    if (fs.existsSync( path.join(__dirname, 'pdfs', 'pdfMerged',nameMerge+'.pdf') )) {
                        console.log('IFasync');

                        //const email = getEmailBySecurityCode( parsedBody.codigoSeguranca );

                        const emailRegiao = getEmailBySecurityCode(parsedBody.codigoSeguranca);


                        const ourEmailAttachments = [
                            {
                                filename:'Contrato de Venda.pdf',
               
                                content:fs.readFileSync(path.join(__dirname, 'pdfs', 'pdfMerged',nameMerge+'.pdf')).toString("base64"),
               
                                contentType: 'application/pdf',
               
                                path:path.join(__dirname, 'pdfs' , 'pdfMerged',nameMerge+'.pdf')
               
                           }
                        ];

                        if(nameCpf) ourEmailAttachments.push(
                            {
                                filename: `CPF.${ nameCpf.split('.').slice(-1)[0] }`,
                
                                content:fs.readFileSync(path.join(__dirname, 'uploads', 'cpfs',nameCpf)).toString("base64"),
 
                                contentType: `image/${nameCpf}`,
               
                                path:path.join(__dirname, 'uploads', 'cpfs' ,nameCpf)
               
                           }                           
                        );

                        if(nameCompEndereco) {
                            ourEmailAttachments.push(
                                {
                                    filename: `Comprovante de Residência.${ nameCompEndereco.split('.').slice(-1)[0]  }`,
                    
                                    content:fs.readFileSync(path.join(__dirname, 'uploads', 'compEnderecos',nameCompEndereco)).toString("base64"),
                   
                                    contentType: `image/${nameCompEndereco}`,
                   
                                    path:path.join(__dirname, 'uploads', 'compEnderecos' ,nameCompEndereco)
                   
                                 }                                 
                            )
                        }

                        if(nameRgFrente) {
                            ourEmailAttachments.push(
                                {
                                    filename: `RG Frente.${ nameRgFrente.split('.').slice(-1)[0] }`,
                    
                                    content:fs.readFileSync(path.join(__dirname, 'uploads', 'rgFrentes', nameRgFrente)).toString("base64"),
                   
                                    contentType: `image/${nameRgFrente}`,
                   
                                    path:path.join(__dirname, 'uploads', 'rgFrentes' ,nameRgFrente)
                   
                                 }
                            )
                        }

                        if(nameRgVerso) {
                            ourEmailAttachments.push(
                                {
                                    filename: `RG Verso.${ nameRgVerso.split('.').slice(-1)[0] }`,
                    
                                    content:fs.readFileSync(path.join(__dirname, 'uploads', 'rgVersos' ,nameRgVerso)).toString("base64"),
                   
                                    contentType: `image/${nameRgVerso}`,
                   
                                    path:path.join(__dirname, 'uploads', 'rgVersos' ,nameRgVerso)
                   
                                 }
                            )
                        }

                        smtpTransport.sendMail({
                    
                            attachments: ourEmailAttachments,
            
                            from:"umuprevtech@gmail.com",
                   
                            to: `ti@umuprev.com.br, ${emailRegiao}`,
                   
                            subject: `Contrato de venda - Títular: ${parsedBody.titular} - Vendedor: ${parsedBody.codigoDoVendedor}`,
                   
                            html:`Segue em anexo fotos dos documentos e o contrato de venda.`,
               
                   
                    },function(error,info){
                        console.log('submit');
               
                   
                            if(error){
                   
                                console.log('error');
                                console.log(error);
                   
                        }
                   
                            else{
                   
                                res.send("Mail has been sended to your email. Check your mail")
                                console.log('1');
                                clearStorage({ 
                                    nameContrato, 
                                    nameDependentes, 
                                    nameMerge, 
                                    nameCpf, 
                                    nameCompEndereco,
                                    nameRgFrente, nameRgVerso
                                });
                   
                        }
                      
                   
                    })
                
            
                     if(!parsedBody.email) return
            
                     smtpTransport.sendMail({
                    
                        attachments:[
               
                            {
                                filename:'Contrato de Venda.pdf',
               
                                content:fs.readFileSync(path.join(__dirname, 'pdfs' , 'pdfMerged',nameMerge+'.pdf')).toString("base64"),
               
                                contentType: 'application/pdf',
               
                                path:path.join(__dirname, 'pdfs' , 'pdfMerged',nameMerge+'.pdf')
               
                           },
                        ],
            
                        from:"umuprevtech@gmail.com",
               
                        to: parsedBody.email,
               
                        subject:'Contrato de venda',
               
                        html:`
               
                        Obrigado por fazer parte da família Umuprev!`,
            
               
                },function(error,info){
            
               
                        if(error){
                            console.log('error');
                            console.log(error);
                            
               
                    }
               
                        else{
               
                            console.log('2');
                            console.log('aaaaaaaaa')
               
                    }
                  
               
                })
                } else {
                    console.log('PDF não enviado com sucesso')
                    console.log('err 2')
                }
                })();


    
            })();
        })


        })


        // const { mimetype } = req.file;

        console.log('pass')
        
         let smtpTransport = nodemailer.createTransport({
        
            host:'smtp.gmail.com',
    
            service:'Gmail',
    
            port:465,
    
            secure:true,

                 auth:{
                     user:process.env.EMAIL_USERNAME,
                     
                     pass:process.env.EMAIL_PASSWORD
                  },
              tls:{rejectUnauthorized:false}
        
         })

         clearStrings();

}